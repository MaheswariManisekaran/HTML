function validation()
{
  var employid=document.getElementById("empid").value;
  var employname=document.getElementById("empname").value;
   var employrole=document.getElementById("role").value;
   var employpassport=document.getElementById("passno.").value;
   var employcountry=document.getElementById("issuedcountry").value;
   var employdependency=document.getElementById("empdependency").value;
   var employspouse=document.getElementById("empspouse").value;
   var employchild=document.getElementById("empchild").value;
   var employmail=document.getElementById("mail_id").value;
   var employchildage=document.getElementById("empchild_age").value;
    var childpassport=document.getElementById("childpassno.").value;
   

      if(employid == "")
      {
      document.getElementById("useridError").innerHTML ="Enter Employee ID"; 
  }
  if(employid .length!=0 && employid.length<6)
  {
    document.getElementById("useridError").innerHTML ="Enter Valid Employee ID"; 
  }
  
  if(employname == "")
      {
      document.getElementById("usernameError").innerHTML ="Enter Employee Name";
     
  }
  if(employrole == "")
      {
      document.getElementById("designationError").innerHTML = " Enter Your Designation";
     
  }
  if(employmail == "")
      {
      document.getElementById("mailidError").innerHTML = " Enter Your Mail Id";
     
  }
 
  
  if(employpassport == "")
      {
      document.getElementById("passportError").innerHTML = " Enter Your Passport Number";
    
  }
  if(employcountry == "")
      {
      document.getElementById("countryError").innerHTML = "Enter Your Country";
     
  }
  if(employchildage >= 1 && employchildage <= 2)
      {
      document.getElementById("ageError").innerHTML = "No Ticket For child";
     
  }

  if(employdependency >= 1 && employspouse == "" && employchild == "" && childpassport == "")
      {
      document.getElementById("dependencyError").innerHTML = "Please Fill Above Fields";
     
 }

   
}
