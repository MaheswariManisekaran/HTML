var pendingEmp=50;
var successEmp=50;
function pending()
{
document.getElementById("demo1").innerHTML =pendingEmp;
}
function processed()
{
document.getElementById("demo2").innerHTML =successEmp;
}
var emp={
        pEmp:pendingEmp,
        sEmp:successEmp,
       };
CanvasJS.addColorSet("colorShades",["#b30000","#008000"]);
window.onload=function() 
{
	var chart=new CanvasJS.Chart("chartContainer", 
	{
	colorSet:"colorShades",
	backgroundColor:"rgba(0, 0, 0, 0.20)",
	animationEnabled:true,
		title:
		{
			text:"STATUS",
			horizontalAlign:"left",
			fontSize:15,
			fontColor:"white",
		},
		data:
		[{
			type: "doughnut",
			startAngle:10,
			//innerRadius: 60,
			indexLabelFontSize:12,
			indexLabelFontColor:"white",
			indexLabel: "{label} - #percent%",
			toolTipContent: "<b>{label}:</b> {y} (#percent%)",
			dataPoints: 
			[
				{ y:parseInt(emp.pEmp,10),label:"pending"},
				{ y:parseInt(emp.sEmp,10),label:"processed"},
			]
		}]
	});
	chart.render();
}     
function datefilter()
{
var sdate=document.getElementById("from").value;
var edate=document.getElementById("to").value;;
console.log(sdate);
console.log(edate);
if(sdate==="" || edate==="")
{
	alert("entered date is null");
}
}
 